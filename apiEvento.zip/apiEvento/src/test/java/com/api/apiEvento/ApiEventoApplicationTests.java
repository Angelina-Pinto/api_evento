package com.api.apiEvento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiEventoApplicationTests {

	@Test
	void contextLoads() {
	}

}
